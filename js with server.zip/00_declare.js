// js with server/00_declare.js

console.log(x);

// var x = 5;
let x = 5;
console.log(x);

// var x = 7;
// let x = 7;
console.log(x);

