// 01_const.js

const user = {
  "id" : "Hong",
  "age" : 25
};
// console.log(user);

user.id = "Kang";
user.age = 20;
user.ssn = "981015";

user = {};

console.log(user);